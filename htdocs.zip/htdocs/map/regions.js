// This is just an example. You can run some scripts to generate regions that
/*
var groupName = "Regions";
var displayName = "Areas";
var world = "top";

markersDB[groupName] = {
	"raw": [
		{
		"fillColor": "#00FF00",
		"fillOpacity": 0.2,
		"strokeColor": "#FF0000",
		"strokeOpacity": 1,
		"polygon" : [
			{"x": 347, "y": 67, "z": 95},
			{"x": 347, "y": 77, "z": 95},
			{"x": 347, "y": 77, "z": 105},
			{"x": 347, "y": 67, "z": 105},
			{"x": 347, "y": 67, "z": 105}
		]}
	],
	"name": "Regions",
	"created": false
}

markers[world].push(
	{
      "groupName": groupName, 
      "icon": "signpost_icon.png", 
      "createInfoWindow": false, 
      "displayName": displayName, 
      "checked": true
	});
*/
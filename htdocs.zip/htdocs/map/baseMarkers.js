// if you wants signs, please see genPOI.py
overviewer.util.injectMarkerScript('markersDB.js');
overviewer.util.injectMarkerScript('markers.js');
overviewer.util.injectMarkerScript('regions.js');
overviewer.collections.haveSigns=true;